import java.io.IOException;
/**
 *
 * @author abilio and pargles
 * @version 1.0
 */
public class Main 
{
	
	public static void main(String[] args) throws IOException, Exception
	{
            NQueens programa = new NQueens(Integer.parseInt(args[0]));
            programa.executa(args[1]);
            /*
            JFrame window = new JFrame("N-Rainhas SO");
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            window.setContentPane(new NrainhasUI());
            window.pack();
            window.show();
            window.setResizable(false);
            */
	}
}


#!/bin/sh
javac *.java
variavel=4
media=0
arq="Rainhas.csv"
#echo $variavel
echo "Executando $variavel Rainhas"
while [ $media != "10" ]; do
   java Main $variavel Paralelo >> $variavel$arq
   media=`expr $media + 1`
done
echo "\n" >> $variavel$arq
media=0
while [ $media != "10" ]; do
   java Main $variavel Sequencial >> $variavel$arq
   media=`expr $media + 1`
done
variavel=`expr $variavel + 1`
echo "Executando $variavel Rainhas"
media=0
while [ $media != "10" ]; do
   java Main $variavel Paralelo >> $variavel$arq
   media=`expr $media + 1`
done
echo "\n" >> $variavel$arq
media=0
while [ $media != "10" ]; do
   java Main $variavel Sequencial >> $variavel$arq
   media=`expr $media + 1`
done
variavel=`expr $variavel + 1`

#!/bin/sh
javac *.java
variavel=4
maximoRainhas=12
arq="Rainhas.csv"
imprimeParalelo(){
local media=0
while [ $media != "10" ]; do
   java Main $variavel Paralelo >> $variavel$arq
   media=`expr $media + 1`
done
}
imprimeSequencial(){
local media=0
while [ $media != "10" ]; do
   java Main $variavel Sequencial >> $variavel$arq
   media=`expr $media + 1`
done
}

while [ $variavel != $maximoRainhas ]; do
   echo "Executando $variavel Rainhas"
   imprimeParalelo
   echo "\n" >> $variavel$arq
   imprimeSequencial
   variavel=`expr $variavel + 1`
done

#echo $variavel






